---
name: Funktionswunsch
about: Ein Vorschlag für RepairCenter
title: ''
labels: wunsch
assignees: ''
---

## Welches Problem soll gelöst werden?

<!-- Bitte das Problem beschreiben, nicht nur die gewünschte Lösung. -->

## Vorgeschlagene Lösung

## Passt der Vorschlag zu den Grundsätzen?

- [ ] Er repariert oder wartet – er „tuned" nicht.
- [ ] Er kommt ohne Fremdmodule und ohne Internetverbindung aus.
- [ ] Jeder verändernde Schritt ließe sich mit `-WhatIf` simulieren.
- [ ] Neue Texte könnten in Deutsch **und** Englisch geliefert werden.

## Alternativen, die du erwogen hast
