## Was ändert dieser Pull Request?

<!-- Kurze Zusammenfassung. Bei Fehlerbehebungen bitte das Issue verlinken. -->

## Prüfliste

- [ ] **Bei einer Fehlerbehebung: Versionsnummer erhöht** –
      `.\tools\Update-Version.ps1 -BumpPatch -Reason "..."`
- [ ] `.\tools\Update-Version.ps1 -Check` ohne Abweichung
- [ ] `.\tests\Test-RepairCenter.ps1` läuft durch (101/101)
- [ ] `npm test` läuft durch (83/83), falls die Oberfläche betroffen ist
- [ ] `.\tests\Test-Compat51.ps1` ohne Befund (Windows PowerShell 5.1)
- [ ] Neue Texte in `web/i18n/de.json` **und** `web/i18n/en.json`
- [ ] Verändernde Schritte nutzen `SupportsShouldProcess` und tun bei `-WhatIf` nichts
- [ ] Keine neuen Abhängigkeiten zur Laufzeit
- [ ] `CHANGELOG.md` ergänzt

## Wie wurde es geprüft?

<!-- Getestete Windows-Version, Modus, Wartungsstufe. Demoszenario genügt nicht für
     Änderungen an echten Systemeingriffen. -->
